To install BioFabric, drag the BioFabric.exe file out of
the zip archive onto your desktop.  Double-clicking on the
icon should launch the application.
