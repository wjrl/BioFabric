BioFabric license is in LICENSE.txt; Copyright (c) 2003-2012 Institute for Systems Biology
LICENSE-SUN.txt is for some of the button images in BioFabric.
launch4j-LICENSE refers to the .exe wrapper code used to launch BioFabric on Windows.
