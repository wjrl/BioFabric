BioFabric license is in LICENSE.txt 
Copyright (c) 2003-2018 Institute for Systems Biology
Portions Copyright (c) 2018 Rishi Desai
LICENSE-SUN.txt is for some of the button images in BioFabric.
launch4j-head-LICENSE.txt refers to the .exe wrapper code used to launch BioFabric on Windows.
